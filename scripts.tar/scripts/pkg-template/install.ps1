$setup  = "<setup.exe/msi>"
$assets = "C:\tmp\<directory>\"


& .\archive.exe -o"${assets}" -y
cd ${output}


if(! Test-Path -Path "${assets}\${setup}" -ErrorAction SilentlyContinue | Out-Null)
{
	Write-Host -ForegroundColor Red "${setup}: file not found."
}
else
{
	Write-Host -ForegroundColor Green "[$(Get-Date -Format HH:mm:ss)] [INSTALLING]"

	if($setup.split(".")[1] -eq "exe"){ & .\setup.exe /s }
	if($setup.split(".")[1] -eq "msi"){ msiexec /i .\setup.msi /qn /norestart }
	
	Write-Host -ForegroundColor Green "[$(Get-Date -Format HH:mm:ss)] [COMPLETE]"
}
