#!/usr/bin/python

import pymongo
from bson.objectid import ObjectId


connection = pymongo.Connection()

db = connection["tutorial"]
employees = db["employees"]

employees.insert({"name" : "Stephen Salisbury", 'gender' : 'm', 'phone' : '912-572-4896', 'age' : 23})

cursor = db.employees.find()
for employee in db.employees.find():
	print employee