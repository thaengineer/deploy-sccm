#!/usr/bin/python

# Variables, 
#
# my_integer = 4
# my_string = 'horus'
# my_bool = True
# my_list = ['apple', 'bannana', 'mango']
# my_tuple = (8, 32)
# my_dictionary = {'osiris' : 'toor', 'horus' : 'eyeofhorus'}

# id(my_string)
# hex(id(my_string))
# my_string.__repr__

# raw string value
# my_string = r'raw string\n (escape sequence was skipped.)'

# my_string = """
# ... This is my string
# ... it continues onthis line.
# ... """

# unicode string value
# my_string = u'horus'
#
# convert to string
# str(my_string)
#
# convert back to unicode
# unicode(my_string)

# raw input
# raw_input = raw_input('Please enter a new user name: ')

# strip spaces from the beginning
# uname = uname.strip()
#
# strip spaces from the end
# uname = uname.rstrip()

# convert [0] to uppercase char
# uname_part1 = uname[0].upper()
#
# convert [1:] to lowercase chars
# uname_part2 = uname[1:].lower()

# concatenate strings
# a = 'hello,'
# b = ' '
# c = 'world!'
# abc = a + b + c
# print(abc)
# >>> hello, world!

# repeated sequence in string
# buffer = "C" * 20
#
# slicing - breaking up the string
# string[start:end:steps]
# buffer[0:10:2]
# print(buffer[0:10:2])

# conver an integer to a string
# my_integer = 32
# str(my_integer)

# find the position of a part of a string
# string.find()
# my_string.find('us')
#
# replace 'x' with 'y'
# string.replace()
# my_string.replace('horus', 'osiris')
#
# by default the delimiter is a space
# string.split()
# my_string.split()
# my_string.split('r')

# ip = "192.168.1.10"
# line = "Crack this IP: %s" % ip
# line = "Crack this IP: %s and change username to %s" % (ip, "osiris")

# my_list = [1, 2, 3, 4]
# len(my_list)
# new_list = [1, "osiris", 2, "horus"]
# new_list.append(3)
#
# print the last value in the list
# new_list.pop()
#
# new_list.reverse()
# my_list.insert(2, "kundalini")
# del my_list[2]
