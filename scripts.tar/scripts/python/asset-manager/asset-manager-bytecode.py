#!/usr/bin/python

import sys
import pymongo
from pymongo import MongoClient

def connect_db():
	db_client = MongoClient('mongodb://localhost:27017')

def close_db():
	db.close()

def create_new_db(new_db_name):
	db = new_db_name + ".LUD"

def select_db():
	print('blah')

def create_asset(asset_id,asset_type,asset_serial,asset_os,asset_user):
	db_id = db.insert(asset_id)
	db_type = db.insert(asset_type)
	db_serial = db.insert(asset_serial)
	db_os = db.insert(asset_os)
	db_user = db.insert(asset_user)

def remove_asset():
	print('blah')

def move_asset():
	print('blah')

def view_asset():
	view_db = db.find_one()


# open connection to the database
connect_db()

# create new database
answer = ''
while answer != 1 :
	# ask the user if they would like to create a new database
	choice = raw_input('Would you like to create a new database? (Y/N) ')
	if choice ==  str('Y'):
		# prompt the user to create a new database
		new_db = raw_input('Enter a name for your new database: ')
		create_new_db(new_db)
	elif choice == str('N'):
		answer = 0
		print("New database was not created.")
	else:
		print("You must answer Y/N.")

# create new asset
asset_answer = ''
while asset_answer != str('N'):
	# ask the user if they would like to create a new database
	asset_answer = raw_input('Would you like to create a new database? (Y/N) ')
	str(asset_answer)
	if asset_answer ==  str('Y'):
		# prompt the user to create a new database
		a = raw_input('Enter a new asset id: ')
		b = raw_input('Enter a new asset type: ')
		c = raw_input('Enter a new asset serial: ')
		d = raw_input('Enter a new asset os: ')
		e = raw_input('Enter a new asset user: ')
		create_new_db(a,b,c,d,e)
	elif answer == str('N'):
		print("New database was not created.")
	else:
		print("You must answer Y/N.")

# terminate asset manager
quit = ''
while quit != str('Y'):
	quit = raw_input('Would you like to quit the Asset Manager? (Y/N) ')
	str(quit)
# close the connection to the database
close_db()
sys.exit("Exiting...")




# create connection to MongoDB
# connectMongoDB = pymongo.Connection('mongodb:// localhost:27017')

# select the database name you want (.LUD)
# db = connectMongoDB.LUD

# select the name of the collection (apacheLogs) to store the data
# logs = db.apacheLogs

# close the connection to MongoDB after interacting with it
# connectMongoDB.close()


# $ mongo
# > use LUD
# > show collections
# apacheLogs
# system.indexes
# > db.apacheLogs.find()
# if the output is long, type "it" to go to the next screen
#
# replication:
# $ mongod --port 27018 --bind_ip 192.168.1.10 --dbpath ./mongo10 --rest --replSet LUDev
# $ mongod --port 27019 --bind_ip 192.168.1.19 --dbpath ./mongo10 --rest --replSet LUDev
# $ mongo
# > rs.initiate()
# > rs.status()
#
# delete full apacheLogs collection:
# $ mongo
# > db.apacheLogs.drop()
#
# remove an entry:
# $ mongo
# > db.apacheLogs.remove({"StatusCode" : "404"})
