#!/usr/bin/python

my_str = "Hello World"

my_int = "23"

my_bool = True

my_tuple = (23, 33)

my_list = ["This", "is", "a", "list"]

my_new_list = list()
my_new_list.append("This")
my_new_list.append("is")
my_new_list.append("my")
my_new_list.append("new")
my_new_list.append("list")

my_dict = { "first_name" : "Stephen", "last_name" : "Salisbury", "eye_color" : "Brown" }

print(my_list[3])
# my_list[3] = my_list[3] + "!" is the same thing as the following:
my_list[3] += "!"
print(my_list[3])

print(str(my_tuple[0]))

print(my_dict["first_name"] + " " + my_dict["last_name"] + " has " + my_dict["eye_color"] + " eyes.")

print("{0} {1} has {2} eyes.".format(my_dict["first_name"], my_dict["last_name"], my_dict["eye_color"]))
