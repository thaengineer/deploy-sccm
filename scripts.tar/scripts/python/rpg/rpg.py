#!/usr/bin/python

# Author: Stephen Salisbury
# Date: 14 JUN 2014

import os, sys, time

# variables:
prompt = '> '
mainMenu = """                                    RPG GAME

                                [1] - CONTINIUE
                                [2] - NEW GAME
                                [3] - OPTIONS
                                [4] - EXIT
"""
command_list = """Commands:
  clear         clear the screen
  exit          exit the terminal interface
"""

# functions:
def init_main() :
	# clear the screen
	os.system('clear')
	# print initial help message
	print(mainMenu)

	# open the main menu
	menu_options()

def menu_options() :
	command = raw_input(prompt)

	if command == "1" :
		continue_game()

	elif command == "2" :
		os.system('clear')
		menu_options()

	elif command == "3" :
		os.system('clear')
		menu_options()

	elif command == "4" :
		sys.exit()
	elif command == "exit" :
		sys.exit()

	else :
		os.system('clear')
		print(mainMenu)
		menu_options()

def game_options() :
	option = raw_input(prompt)

	if option == "exit" :
		quitChoice = raw_input("Are you sure you want to quit the game? Y/N ")
		if quitChoice == 'y' :
			menu_options
		elif quitChoice == 'Y' :
			menu_options
		elif quitChoice == 'n' :
			continue_game()
		elif quitChoice == 'N' :
			continue_game()
		else :
			game_options()

def continue_game() :
	os.system('clear')
	print "continuing game!"

	game_options()

# initiate main function:
init_main()