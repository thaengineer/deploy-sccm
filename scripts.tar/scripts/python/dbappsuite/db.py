#!/usr/bin/python

# Application Name: db.py
# Date Created: 04 May 2014
# Author: Stephen Salisbury

# db.py lets you create/remove databases and add/remove db entries.
# the application errors out if no arguments are given.

import sys

def show_help() :
	print 'Usage: db [OPTION] [FILE]'
	print 'List information about students and their grades.'
	print ''
	print '  -h, --help                 display this help and exit'
	print ''
	print '  -c, --create               create a new database'
	print '  -r, --remove               remove a specified database'
	print ''
	print '  -a, --add                  add an entry to a database'
	print '  -d, --delete               delete an entry from a database'
	print ''
	print '  -k, --key                  list database entry'
	print '  -v, --value                list dataase value'
	print ''
	print '  -qu, --query-user'
	print '  -qp, --query-password'
	print ''
	print '  Example 1: list -u'
	print '  Example 2: list -g'

def query_user() :
	print(users_db[0::2])

def query_pass() :
	print(users_db[1::2])

def new_user() :
	uname = raw_input('Enter a new username: ')
	pword = raw_input('Enter a new password: ')
	users_db.append(uname)
	users_db.append(pword)

def db_options(option) :
	if option == '-h' :
		show_help()
	elif option == '--help' :
		show_help()
	elif option == '-c' :
		new_user()
	elif option == '--create' :
		new_user()
	elif option == '-r' :
		remove_entry()
	elif option == '--remove' :
		remove_entry()
	elif option == '-a' :
		()
	elif option == '--add' :
		()
	elif option == '-d' :
		()
	elif option == '--delete' :
		()
	elif option == '-k' :
		()
	elif option == '--key' :
		()
	elif option == '-v' :
		()
	elif option == '--value' :
		()
	elif option == '-qu' :
		query_user()
	elif option == '--query-user' :
		query_user()
	elif option == '-qp' :
		query_pass()
	elif option == '--query-password' :
		query_pass()
	elif option == './db.py' :
		print('list: invalid option -- ' + "'" + option[7:] + "'")
	else :
		print('list: invalid option -- ' + "'" + option + "'")
		sys.exit()


users_db = ['admin', 'password']

db_options(sys.argv[1])
query_user()
query_pass()