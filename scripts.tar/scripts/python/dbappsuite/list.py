#!/usr/bin/python

# Application Name: list.py
# Date Created: 04 May 2014
# Author: Stephen Salisbury

# list.py lists names and date of births from a dictionary.
# the application errors out if no arguments are given.

import sys

dictionary = {'kai' : 1989, 'stephen' : 1991, 'byron' : 1992, 'adrian' : 1995}

def list_users() :
	print(dictionary.keys())

def list_grades() :
	print(dictionary.values())

def show_help() :
	print '''
Usage: list [OPTION]
List information about students and their grades.

  -h, --help                 display this help and exit
  -n, --names                list all users
  -d, --dob                  list all Grades

  Example 1: list -u
  Example 2: list -g
'''


def list_info(option) :
	if option == '-n' :
		list_users()
	elif option == '--names' :
		list_users()
	elif option == '-d' :
		list_grades()
	elif option == '--dob' :
		list_grades()
	elif option == '-h' :
		show_help()
	elif option == '--help' :
		show_help()
	elif option == './list.py' :
		print('list: invalid option -- ' + "'" + option[9:] + "'")
	else :
		print('list: invalid option -- ' + "'" + option + "'")
		sys.exit()

list_info(sys.argv[1])