#!/usr/bin/python

import sys

try :
	option = sys.argv[1]
	
except :
	print """
  AVTOPILOT Industries
  PROJECT SANDMAN
  A simple sandbox app.

  Usage: sandbox.py [OPTION] ...

    -h, --help              Display this help message


  Example: sandbox.py -h
"""
	# close the program
	sys.exit()

# declare some variables here:
counter = 0

# declare functions:
def loadSave() :
	
	load = open('', 'r')
	bars = ["|"]

	for i in bars :
		print(%s, bar)

def sandmanInit() :
	progressBar()

# some code:

if option == 1 :
	# Initialize sandman protocol lol:
	sandmanInit()