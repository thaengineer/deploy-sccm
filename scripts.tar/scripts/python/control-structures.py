#!/usr/bin/python

import sys # Used for the sys.exit function

int_condition = raw_input("Enter a number > 6 to continue: ")

try:
	int_condition = int(int_condition)
except ValueError:
	sys.exit("You must enter an integer!")

if int_condition < 6:
	sys.exit("Exiting...")
else:
	print("int_condition was >= 6 - continuing")

print("still running...")

count = 0

while count <= 100:
	print(int(count))
	count += 1

print("")

print("Counted to 100.")

print("")

while count < target_int:
	new_int = raw_input(“Please enter integer {0}: “.format(count + 1))
	isint = False
	try:
		new_int = int(new_int)

	except:
		print(“You must enter an integer”)

	if isint == True:
		# Add the integer to the collection
		ints.append(new_int)
		# Increment the count by 1
		count += 1

print(“Using a for loop”)
for value in ints:
	print(str(value))

# Or with a while loop:
print(“Using a while loop”)
# We already have the total above, but knowing the len function is very
# useful.
total = len(ints)
count = 0
while count < total:
	print(str(ints[count]))
	count += 1
