#!/usr/bin/python

# Modules:
import os, sys, time

# Variables:
prompt = '> '
help_message = """AVTOPILOT Industries
PROJECT T-1
A terminal emulator that executes user input if valid.
Usage: terminal.py

  -h            display a list of all commands
"""
command_list = """Commands:
  clear         clear the screen
  exit          exit the terminal interface
"""

# Functions:
def main() :
	# Clear the screen
	os.system('clear')
	# Print initial help message
	print (help_message)

	# Initiate the terminals command prompt
	init_terminal()

def init_terminal() :
	command = raw_input(prompt)

	if command == "-h" :
		print(command_list)
		init_terminal()
	elif command == "clear" :
		os.system('clear')
		init_terminal()
	elif command == "exit" :
		sys.exit()
	else :
		init_terminal()

# Main program starts here:
main()