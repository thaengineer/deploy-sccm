#!/usr/bin/python

# Application Name: list.py
# Date Created: 04 May 2014
# Author: Stephen Salisbury

# list.py lists names and date of births from a dictionary.
# the application errors out if no arguments are given.

import sys

dictionary = {'kai' : 1989, 'stephen' : 1991, 'byron' : 1992, 'adrian' : 1995}

def list_users() :
	print(dictionary.keys())

def list_grades() :
	print(dictionary.values())

def show_help() :
	print 'Usage: list [OPTION]'
	print 'List information about students and their grades.'
	print ''
	print '  -h, --help                 display this help and exit'
	print '  -n, --names                list all users'
	print '  -d, --dob                  list all Grades'
	print ''
	print '  Example 1: list -u'
	print '  Example 2: list -g'


def list_info(option) :
	if option == '-n' :
		list_users()
	elif option == '--names' :
		list_users()
	elif option == '-d' :
		list_grades()
	elif option == '--dob' :
		list_grades()
	elif option == '-h' :
		show_help()
	elif option == '--help' :
		show_help()
	elif option == './testing.py' :
		print('list: invalid option -- ' + "'" + option[12:] + "'")
	else :
		print('list: invalid option -- ' + "'" + option + "'")
		sys.exit()

list_info(sys.argv[1])