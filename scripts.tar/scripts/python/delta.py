#!/usr/bin/python

# Author: Stephen Salisbury
# Date: 11 MAY 2014
# Application Name: -?-
# Purpose: -?-

import socket
import sys
import time

socket.setdefaulttimeout(5)
counter = 0

try:
	host = sys.argv[1]
	port = int(sys.argv[2])
	try:
		tries = 0	
	except:
		tries = 1
except:
	prog_info = """Usage: delta.py -h [TARGET_IP] -p [TARGET_PORT]

  Triangulate a target's geo location.

  -h, --hostname              target IP-Address
  -p, --port                  target port


  example: delta.py -h 127.0.0.1 -p 80 -m c7:d8:e9:f0:5a:6b -i wlan0

  Author: Stephen Salisbury
  Date: 11 MAY 2014
  Version 1.0
"""
	print(prog_info)
	sys.exit()

ADDR = (host, port)

def triangulate():
	getReq = "GET /tmp HTTP/1.0"
	while counter <= tries:
		try:
			client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			client_socket.connect(ADDR)
			client_socket.sendall(getReq)
			print ">> Triangulating target..."
			client_socket.close()
			counter += 1
			time.sleep(5)
		except:
			print ">> Unable to locate target!"
			client_socket.close()
			time.sleep(5)
			triangulate()
			counter += 1

triangulate()