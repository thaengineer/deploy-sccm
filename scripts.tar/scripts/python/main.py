#!/usr/bin/python

import sys

def buffer_overflow(value):

	a = value
	b = 333123
	c = 444321
	my_buffer = a * b * c

	while True:
		print(my_buffer)

buffer_overflow(sys.argv[1])