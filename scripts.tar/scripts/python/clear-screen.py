#!/usr/bin/python

import os, sys

# Windows
os.system('cls')

# Linux
os.system('clear')

# exit
sys.exit()
