#!/bin/bash


clear
echo ""
echo "Backing up files..."
echo ""


src_001="/home/stephen/*"
src_002="/home/stephen/Desktop/"
src_003="/home/stephen/Documents/"
src_004="/home/stephen/Downloads/"
src_005="/home/stephen/Music/"
src_006="/home/stephen/Pictures/"
src_007="/home/stephen/Videos/"
src_008="/home/stephen/workspace/"
dst=/media/stephen/backup/backup_03jul2015/


cp -f -r -u -v $src_001 $dst
cp -f -r -u -v $src_002 $dst
cp -f -r -u -v $src_003 $dst
cp -f -r -u -v $src_004 $dst
cp -f -r -u -v $src_005 $dst
cp -f -r -u -v $src_006 $dst
cp -f -r -u -v $src_007 $dst
cp -f -r -u -v $src_008 $dst

seep 5
clear
echo ""
echo "Backup completed!"
sleep 5
