# Set variables
$idFile = "" # Set the .id file name
$uname = "" # User, format: FIRST LAST
$notesPw = @{"Notes?123", "password"} # Lotus notes passwords in an array
$dominoSvr = "hades"
$timeFrom = "12:00 AM"
$timeTo = "11:59 PM"
$idShare"\\zeus\deathrow"

$auto = New-Object -com "Wscript.Shell" # Usage e.g: $auto.SendKeys("{TAB}")

Invoke-Item ("C:\Notes\notes.exe") # Launch lotus notes
Start-Sleep -Seconds 10 # Pause script for 10 seconds

if(Test-Path -Path "${idShare}\${idFile}" -ErrorAction SilentlyContinue)
{
    Copy ".id" "C:\Notes\Data"
}

# $auto.SendKeys('')

$auto.AppActivate("C:\Notes\notes.exe") # 
$auto.SendKeys("{TAB}")
$auto.SendKeys('{HOME}')
$auto.SendKeys('{END}')
$auto.SendKeys('{BACKSPACE}')
$auto.SendKeys('DELETE')
$auto.SendKeys('^C') # Send Ctrl + C (Copy)
$auto.SendKeys('^P') # Send Ctrl + P (Paste)
$auto.SendKeys('{+}')
$auto.SendKeys('-')
$auto.SendKeys('{ENTER}')
$auto.SendKeys('{TAB}') # Send Tab
$auto.SendKeys('+{TAB}') # Send Shift + Tab

Start-Sleep -Seconds 10 # Pause script for 10 seconds
$auto.SendKeys('%F4') # Send Alt + F4
