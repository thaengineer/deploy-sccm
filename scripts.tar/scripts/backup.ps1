$source = "${home}"
$dest   = "C:\backup"

Write-Host "[$(Get-Date -Format HH:mm:ss)] [BACKUP]"
Copy-Item -Path ${source} -Destination $dest -Container -Force -Recurse -ErrorAction SilentlyContinue
Write-Host "[$(Get-Date -Format HH:mm:ss)] [COMPLETE]"

#Write-Host "[$(Get-Date -Format HH:mm:ss)] [RESTORE]"
#xcopy ".\backup\*" "C:\Users\%username%\" /d /e /c /i /g /r /y /z
#Write-Host "[$(Get-Date -Format HH:mm:ss)] [COMPLETE]"
