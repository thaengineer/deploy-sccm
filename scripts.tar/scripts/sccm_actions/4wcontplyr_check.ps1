# Author: Stephen Salisbury


# Popup Balloon Function
function popUpBalloon{
param([string]$tipText)
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
        $objNotifyIcon = New-Object System.Windows.Forms.NotifyIcon 
        $objNotifyIcon.Icon = "C:\Windows\System32\PerfCenterCpl.ico"
        $objNotifyIcon.BalloonTipIcon = "Warning" #Info, Warning , Error 
        $objNotifyIcon.BalloonTipText = $tipText 
        $objNotifyIcon.BalloonTipTitle = "Content Player Offline"
        $objNotifyIcon.Visible = $True 
        $objNotifyIcon.ShowBalloonTip(3000)
}


# Define the workstation to run the client actions on
$hostNames = Get-Content "C:\scripts\sccm_actions\4wcontplyrs.txt"

foreach($hostName in $hostNames) {
    If(Test-Connection -ComputerName $hostName -Count 1 -Quiet) {
        Write-Host -foregroundcolor DarkGreen $hostName
    }
    Else {
        Write-Host -foregroundcolor DarkRed $hostName
        
		# to call function, use:
		# multiple lines can be called with newline (`n)
		#popUpBalloon("Insert text here`nInsert second line here`nInsert third line here")
		popUpBalloon("$(Get-Date) $hostName is offline")
		Start-Sleep -seconds 3
    }
}
