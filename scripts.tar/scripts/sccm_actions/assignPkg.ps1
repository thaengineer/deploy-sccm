Import-Module ActiveDirectory

$computers = Get-Content -Path "C:\scripts\sccm_actions\hosts.txt"

foreach($computer in $computers)
{
    $system = Get-ADComputer -Identity $computer
    Add-ADGroupMember -Identity "Microsoft Access 2010 Run Time - GS0067" -Members $system
	# Remove-ADGroupMember -Identity "Microsoft Access 2003 Runtime - GS6163" -Members $system
}

# Sleep for 30 seconds
Start-Sleep -seconds 5