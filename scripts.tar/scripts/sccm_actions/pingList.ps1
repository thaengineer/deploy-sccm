# ConfigMan Client Actions
# Author: Stephen Salisbury


# Define the workstation to run the client actions on
$hostNames = Get-Content "C:\scripts\sccm_actions\hosts.txt"

foreach($hostName in $hostNames) {
    If(Test-Connection -ComputerName $hostName -Count 1 -Quiet) {
        Write-Host -foregroundcolor DarkGreen $hostName
        $hostName | Out-File -append "C:\scripts\sccm_actions\good.txt"
    }
    Else {
        Write-Host -foregroundcolor DarkRed $hostName
        $hostName | Out-File -append "C:\scripts\sccm_actions\bad.txt"
    }
}


# Sleep for 30 seconds
Start-Sleep -seconds 5

# Remove the good & bad ping lists
# Remove-Item -path "C:\scripts\sccm_actions\good.txt"
# Remove-Item -path "C:\scripts\sccm_actions\bad.txt"