# ConfigMan Client Actions
# Author: Stephen Salisbury


# Define the workstation to run the client actions on
$hostNames = Get-Content "C:\scripts\sccm_actions\hosts.txt"

foreach($hostName in $hostNames) {
    If(Test-Connection -ComputerName $hostName -Count 1 -Quiet) {
        Write-Host -foregroundcolor DarkGreen $hostName
        $hostName | Out-File -append "C:\scripts\sccm_actions\good.txt"
    }
    Else {
        Write-Host -foregroundcolor DarkRed $hostName
        $hostName | Out-File -append "C:\scripts\sccm_actions\bad.txt"
    }
}

$goodList = Get-Content "C:\scripts\sccm_actions\good.txt"
# $badList = Get-Content "C:\scripts\sccm_actions\bad.txt"

Start-Sleep -seconds 5

# Run these actions for each hostname listed in hosts.txt
foreach($hostName in $goodList) {

    # Runs a Hardware Inventory Cycle
    Invoke-WmiMethod -ComputerName $hostName -Namespace root\CCM -Class SMS_Client -Name TriggerSchedule -ArgumentList "{00000000-0000-0000-0000-000000000001}"

    # Runs a Software Inventory Cycle
    Invoke-WmiMethod -ComputerName $hostName -Namespace root\CCM -Class SMS_Client -Name TriggerSchedule -ArgumentList "{00000000-0000-0000-0000-000000000002}"

    # Runs a Machine Policy Retrieval & Evaluation Cycle
    Invoke-WmiMethod -ComputerName $hostName -Namespace root\CCM -Class SMS_Client -Name TriggerSchedule -ArgumentList "{00000000-0000-0000-0000-000000000021}"

    # Runs a Software Updates Scan Cycle
    Invoke-WmiMethod -ComputerName $hostName -Namespace root\CCM -Class SMS_Client -Name TriggerSchedule -ArgumentList "{00000000-0000-0000-0000-000000000113}"

    # Runs a File Collection Cycle
    Invoke-WmiMethod -ComputerName $hostName -Namespace root\CCM -Class SMS_Client -Name TriggerSchedule -ArgumentList "{00000000-0000-0000-0000-000000000010}"

}

# Sleep for 30 seconds
Start-Sleep -seconds 25

# Remove the good & bad ping lists
Remove-Item -path "C:\scripts\sccm_actions\good.txt"
Remove-Item -path "C:\scripts\sccm_actions\bad.txt"