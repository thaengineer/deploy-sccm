﻿$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut("C:\scripts\Lotus Notes 8.5.lnk")
$Shortcut.TargetPath = "C:\Notes\notes.exe"
$Shortcut.Arguments = '"=c:\Notes\notes.in"'
$Shortcut.WorkingDirectory = "C:\Notes\framework\"
$Shortcut.Description = "Lotus Notes Client"
$Shortcut.Save()
