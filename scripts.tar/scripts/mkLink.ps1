﻿$hostName = "lcnu419bh4m"

$WshShell = New-Object -comObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut(".\Lotus Notes 8.5.lnk")
$Shortcut.TargetPath = "C:\Notes\notes.exe"
$Shortcut.Arguments = '"=C:\Notes\notes.in"'
$Shortcut.WorkingDirectory = "C:\Notes\framework\"
$Shortcut.Description = "Lotus Notes Client"
$Shortcut.Save()
