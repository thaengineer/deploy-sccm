$origin = "Stephen Salisbury <stephen.salisbury@gulfstream.com>"
$dest = "Stephen Salisbury <stephen.salisbury@gulfstream.com>"
$subj = "This is a test"
$message = "<!DOCTYPE html><html><head><style>body {font-family: Arial; font-size: 12px;}</style></head><body><div id="intro">Good afternoon,</div><br><div id="message">I am sending you this email to notify you that per REQ000000, "Putty" has been successfully installed on LCNU000ABCD.</div><br><br><div id="sigstart">Regards,</div><br><div id="name">Stephen Salisbury</div><div id="title">HCL Deskside Support Technician</div><div id="company">Gulfstream Aerospace Corporation</div><div id="number">Desk: (912) 251 - 1933</div><br><div id="footer">This e-mail message, including all attachments, is for the sole use of the intended recipient(s) and may contain Personal Information under General Dynamics policy CP 07-105 and/or legally privileged and confidential information.  Any Personal Information can be<br>accessed only by authorized personnel of General Dynamics and its approved service providers and may be used only as permitted by General Dynamics and its policies.  Contractual restrictions apply to third parties.  If you are not an intended recipient, you are<br>hereby notified that you have either received this message in error or through interception, and that any review, use, distribution, copying or disclosure of this message or its attachments is strictly prohibited and is subject to criminal and civil penalties.  All personal<br>messages express solely the sender's views and not those of Gulfstream Aerospace Corporation.<br>If you received this message in error, please contact the sender by reply e-mail and destroy all copies of the original message.</div></body></html>"
$smtpsvr = "mailman.gulfaero.com"


# Also can use -BodyAsHtml instead of -Body
# Other Options:
# -UseSsl
# -Encoding 'UTF8'
Send-MailMessage -To $dest -Subject $subj -From $origin -BodyAsHtml $message -SmtpServer $smtpsvr
Start-Sleep -Seconds 1